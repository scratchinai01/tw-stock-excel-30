# 台股分析 Excel 系統（30 階段教學專案）

這個資料夾是「Claude Code × Excel 台股分析系統」30 階段課程的起點。
目標：用 Python 在本機抓台股資料，產生 output/stock_system.xlsx，內含股價、技術指標、圖表、儀表板與回測。

教學網頁（30 張複製卡）：https://tw-stock-excel-30.web.app

## 每個階段都要遵守的規則
1. 每次只做我貼給你的那一個階段，不要提前做後面的功能。
2. 程式與註解使用繁體中文說明，Excel 工作表名稱、欄位名稱一律用繁體中文。
3. Excel 一律由 scripts/build_workbook.py 從頭重建；不要用 load_workbook 讀進既有檔案再存檔（會遺失圖表）。只讀取、不存檔可以。
4. 存檔一律走 safe_save()：若 stock_system.xlsx 正在 Excel 開啟 → 先備份 → 自動「儲存並關閉」這一個活頁簿（不要用 active workbook，不動其他檔案，絕不按「不儲存」）→ 存成暫存檔 → 檢查 → 舊檔移到 output/backup/（留 5 份）→ 取代正式檔。自動關閉失敗時才停下來提醒我。
5. 技術指標能用 Excel 公式就用公式。STDEV.P 等新函數要寫成 _xlfn.STDEV.P。
6. 台股慣例：上漲紅色、下跌綠色。
7. 檢查用的程式寫成 checks/ 裡的 .py 檔再執行，不要用一長串 python -c。
8. 遇到網路錯誤（DNS、無法解析主機）先停下來，列出需要允許的網域，等我核准。
9. 檔案結構檢查通過，不代表 Excel 會正確顯示：有圖表或公式的階段，完成後都請我打開 Excel 實際確認。
10. 每個階段完成後，用三行告訴我：改了哪些檔案、要執行什麼指令、打開 Excel 要檢查哪裡。

## 資料夾用途
- data/：股價 CSV、抓取紀錄
- scripts/：Python 程式（build_workbook.py、fetch_data.py、update.py……）
- output/：產生的 Excel；output/backup/ 放自動備份（保留 5 份）
- checks/：檢查用的 .py 程式

## 開始方式
學員會依序貼上 30 張階段卡片。收到卡片前，不要主動寫程式。
