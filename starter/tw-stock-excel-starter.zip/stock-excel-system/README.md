# 台股分析 Excel 系統

用 Python 抓台股資料，產生 output/stock_system.xlsx，內含股價、技術指標、圖表、儀表板與回測。

## 設計原則
- Excel 一律由 scripts/build_workbook.py 從頭重建，不用 load_workbook 讀進既有檔案再存檔（openpyxl 不會保留原有圖表）。
- 存檔一律走 safe_save()：暫存檔 → 檢查 → 備份到 output/backup/ → 取代正式檔。

## 資料夾結構
```
stock-excel-system/
├── CLAUDE.md        Claude Code 自動讀取的規則
├── README.md        本說明
├── data/            股價 CSV
├── scripts/         Python 程式
├── output/          產生的 Excel
│   └── backup/      自動備份（保留 5 份）
└── checks/          檢查用程式
```

## 怎麼開始
1. 在終端機進入這個資料夾，輸入 `claude` 啟動 Claude Code。
2. 打開教學網頁 https://tw-stock-excel-30.web.app ，從「階段 1」開始，一張一張複製貼上。

設計：智慧未來領袖學苑｜LINE ID：snake0203cheng
本專案僅供教學，不構成投資建議。
