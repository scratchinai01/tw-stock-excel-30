# 台股分析 Excel 系統

用 Python 抓台股資料，產生 output/stock_system.xlsx，內含股價、技術指標、圖表、儀表板與回測。

## 設計原則
- Excel 一律由 scripts/build_workbook.py 從頭重建，不用 load_workbook 讀進既有檔案再存檔（openpyxl 不會保留原有圖表）。
- 存檔一律走 safe_save()：暫存檔 → 檢查 → 備份到 output/backup/ → 取代正式檔。

## 資料夾結構
```
stock-excel-system/
├── AGENTS.md        AI 規則（Codex 等工具讀取）
├── CLAUDE.md        AI 規則（Claude Code 讀取）
├── GEMINI.md        AI 規則（Gemini 系列工具讀取）
├── README.md        本說明
├── data/            股價 CSV
├── scripts/         Python 程式
├── output/          產生的 Excel
│   └── backup/      自動備份（保留 5 份）
└── checks/          檢查用程式
```

## 怎麼開始（不需要終端機）
1. 用你的 AI 工具（Antigravity、Codex 或 Claude Code）打開這個資料夾。
2. 打開教學網頁 https://tw-stock-excel-30.web.app ，從「階段 1」開始，一張一張複製貼上。

AGENTS.md、CLAUDE.md、GEMINI.md 是同一份規則，分別給不同的 AI 工具讀取，不用修改。

設計：智慧未來領袖學苑｜LINE ID：snake0203cheng
本專案僅供教學，不構成投資建議。
